import { createContext, useState } from "react";
import type { OmdbSearchResult } from "../models/omdb";

const Context = createContext({});

// TODO: Crear un hook con la logica para manejar los favoritos
export const Provider = ({ children }: { children: React.ReactNode }) => {
  const [lastpage, setLastpage] = useState("");
  const [fav, setFav] = useState<OmdbSearchResult[]>([]);

  return (
    <Context value={{ lastpage, setLastpage, fav, setFav }}>{children}</Context>
  );
};
